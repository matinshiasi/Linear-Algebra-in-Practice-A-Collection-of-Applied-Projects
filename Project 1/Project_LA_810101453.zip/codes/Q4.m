clc; clear; close all;

%% Part A
a1 = [1; 2; 2];
a2 = [2; 0; 1];
a3 = [3; 2; 1];

q1 = a1 / norm(a1);

proj_a2_q1 = (dot(a2, q1)) * q1;
u2 = a2 - proj_a2_q1;
q2 = u2 / norm(u2);

proj_a3_q1 = (dot(a3, q1)) * q1;
proj_a3_q2 = (dot(a3, q2)) * q2;
u3 = a3 - proj_a3_q1 - proj_a3_q2;
q3 = u3 / norm(u3);

disp('q1 ='); disp(q1);
disp('q2 ='); disp(q2);
disp('q3 ='); disp(q3);


disp('q1^T q2 ='); disp(dot(q1, q2));
disp('q1^T q3 ='); disp(dot(q1, q3));
disp('q2^T q3 ='); disp(dot(q2, q3));

disp('||q1|| ='); disp(norm(q1));
disp('||q2|| ='); disp(norm(q2));
disp('||q3|| ='); disp(norm(q3));

%% Part B
u = 4 * a1 + 5 * a2;

u_hat = (q1 * (q1' * u)) + (q2 * (q2' * u));

reconstruction_error = norm(u - u_hat);

disp('Projected user vector (û):');
disp(u_hat);

disp('Reconstruction error ||u - û||:');
disp(reconstruction_error);

%% Part C
r_cos = dot(u, a3) / (norm(u) * norm(a3));
r_proj = dot(u_hat, a3) / norm(a3);

disp('r_3^{(cos)}:');
disp(r_cos);

disp('r_3^{(proj)}:');
disp(r_proj);
