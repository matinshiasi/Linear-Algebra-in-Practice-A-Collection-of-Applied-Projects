clc; clear; close all;

%% Part A
n = 2000;
S = eye(n);
df = n + 10;
A = wishrnd(S, df);
a = rand(n, 1);

%% Part B
tic;
B = A + a * a';
R = chol(B);
inv_R = inv(R);
inv_B = inv_R' * inv_R;
elapsed_time = toc;
disp(['Time elapsed Cholesky: ', num2str(elapsed_time), ' seconds']);

%% Part C
tic;
inv_A = inv(A);
numerator = (inv_A * a) * (a' * inv_A);
denominator = 1 + a' * inv_A * a;
inv_B_SM = inv_A - numerator / denominator;
elapsed_time_SM = toc;
disp(['Time elapsed Sherman–Morrison: ', num2str(elapsed_time_SM), ' seconds']);

%% Part D
m = 5000;
A = wishrnd(S, df);
B = triu(randn(n, m));

%% Part E
tic;
C = A + B * B';
R = chol(C);
inv_R = inv(R);
inv_C = inv_R' * inv_R;
elapsed_time = toc;
disp(['Time elapsed Cholesky (BBᵗ): ', num2str(elapsed_time), ' seconds']);

%% Part F
tic;
invA = inv(A);
Bt_invA = B' * invA;
middle = inv(eye(m) + Bt_invA * B);
inv_C_woodbury = invA - invA * B * middle * Bt_invA;
elapsed_time_woodbury = toc;
disp(['Time elapsed Woodbury: ', num2str(elapsed_time_woodbury), ' seconds']);
