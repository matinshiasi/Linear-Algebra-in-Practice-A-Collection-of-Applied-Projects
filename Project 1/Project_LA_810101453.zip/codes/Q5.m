clc; clear; close all;

%% part A
H = [1 0; 0 -1];

X = [3 1 2 0;
     1 5 1 2;
     4 0 3 1;
     2 2 0 4];

Y = zeros(3, 3);

for i = 1:3
    for j = 1:3
        patch = X(i:i+1, j:j+1);
        Y(i,j) = sum(sum(H .* patch));
    end
end

disp('Output matrix Y:');
disp(Y);

%% part B
Z(:, :, 1) = [1 0 2 3; 0 1 1 0; 2 2 0 1; 1 0 1 2];
Z(:, :, 2) = [0 2 1 1; 2 1 0 2; 1 0 2 2; 0 1 1 0];
Z(:, :, 3) = [2 1 0 2; 1 0 2 1; 0 1 1 0; 2 2 0 1];

[~, ~, c] = size(Z);
Y_rgb = zeros(3, 3, c);

for k = 1:c
    for i = 1:3
        for j = 1:3
            patch = Z(i:i+1, j:j+1, k);
            Y_rgb(i,j,k) = sum(sum(H .* patch));
        end
    end
end

for k = 1:3
    fprintf('Output of channel %d:\n', k);
    disp(Y_rgb(:, :, k));
end
