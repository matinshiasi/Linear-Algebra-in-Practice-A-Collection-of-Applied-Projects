clc; clear; close all;

%% Part A
n = 2; N = 100;

x = wblrnd(1, 2, N, n);
x = 2 * (x - min(x, [], 'all')) / (max(x, [], 'all') - min(x, [], 'all')) - 1;

y = poissrnd(2, N, 1);
y = (y - min(y)) / (max(y) - min(y));

idx = randperm(N);
N_test = round(0.2 * N);
test_idx = idx(1:N_test);
train_idx = idx(N_test+1:end);

x_train = x(train_idx, :);
y_train = y(train_idx);
x_test = x(test_idx, :);
y_test = y(test_idx);

%% Part B & C
xi = x_train(1, :)'; yi = y_train(1);
W = randn(n, 1); b = randn;

z = W' * xi + b;
s = 1 / (1 + exp(-z));

dL_dz = -exp(-z) / ((1 + exp(-z))^2); 
dL_dW = dL_dz * xi;               
dL_db = dL_dz;

disp('Gradient wrt W:'); disp(dL_dW);
disp('Gradient wrt b:'); disp(dL_db);

sigmoid_prime = s * (1 - s);
sigmoid_double_prime = sigmoid_prime * (1 - 2 * s);

H_WW = sigmoid_double_prime * (xi * xi');
H_bb = sigmoid_double_prime;
H_Wb = sigmoid_double_prime * xi;

disp('Hessian wrt W:'); disp(H_WW);
disp('Hessian wrt b:'); disp(H_bb);
disp('Hessian cross term (W,b):'); disp(H_Wb);

%% Part D
grad = [dL_dW; dL_db];
H = [H_WW, H_Wb; H_Wb', H_bb];

alpha = [W; b];
alpha_new = alpha - H \ grad;

W_new = alpha_new(1:n);
b_new = alpha_new(end);

disp('Updated W using Newton:'); disp(W_new);
disp('Updated b using Newton:'); disp(b_new);

%% Part E & F
W = randn(n,1); b = randn;
epsilon = 0.01; max_iter = 1000;

train_losses = [];
test_losses = [];

for iter = 1:max_iter
    grad_sum = zeros(n+1, 1);
    hess_sum = zeros(n+1, n+1);
    total_loss_train = 0;

    for i = 1:length(y_train)
        xi = x_train(i, :)'; yi = y_train(i);
        z = W' * xi + b;
        s = 1 / (1 + exp(-z));

        dL_dz = -exp(-z) / ((1 + exp(-z))^2);
        dL_dW = dL_dz * xi;
        dL_db = dL_dz;

        grad = [dL_dW; dL_db];
        grad_sum = grad_sum + grad;

        sig_p = s * (1 - s);
        sig_pp = sig_p * (1 - 2 * s);

        H_WW = sig_pp * (xi * xi');
        H_bb = sig_pp;
        H_Wb = sig_pp * xi;

        H = [H_WW, H_Wb; H_Wb', H_bb];
        hess_sum = hess_sum + H;

        total_loss_train = total_loss_train + abs(yi - s);
    end

    grad_avg = grad_sum / length(y_train);
    hess_avg = hess_sum / length(y_train);

    lambda = 0.5 * grad_avg' * (hess_avg \ grad_avg);
    train_losses(end+1) = total_loss_train / length(y_train);

    s_test = 1 ./ (1 + exp(-(x_test * W + b)));
    test_loss = sum(abs(y_test - s_test)) / length(y_test);
    test_losses(end+1) = test_loss;

    alpha = [W; b];
    alpha_new = alpha - hess_avg \ grad_avg;
    W = alpha_new(1:n); b = alpha_new(end);

    if lambda < epsilon
        break;
    end
end

disp('Final W:'); disp(W);
disp('Final b:'); disp(b);
disp(['Iterations: ', num2str(iter)]);

figure;
plot(train_losses, 'b-o'); hold on;
plot(test_losses, 'r-o');
legend('Train Loss','Test Loss');
xlabel('Iteration'); ylabel('Loss');
title('Loss vs Iteration (Newton Update)');
grid on;
