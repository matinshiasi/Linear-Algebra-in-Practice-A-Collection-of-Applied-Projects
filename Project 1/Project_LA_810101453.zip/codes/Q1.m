clc; clear; close all;

%% Part A
n = 30; N = 200;
weibull_k = 2; weibull_lambda = 1;
x = wblrnd(weibull_lambda, weibull_k, N, n);
x = 2 * (x - min(x, [], 'all')) / (max(x, [], 'all') - min(x, [], 'all')) - 1;

lambda_poisson = 3;
y = poissrnd(lambda_poisson, N, 1);
y = 2 * (y - min(y)) / (max(y) - min(y)) - 1;

figure;
subplot(2,1,1); histogram(x(:,1)); title('Histogram of x (first dimension)');
subplot(2,1,2); histogram(y); title('Histogram of y');

figure;
stem(xcorr(y, x(:,1), 'coeff'));
title('Cross-Correlation of y and x(:,1)'); xlabel('Lags'); ylabel('Correlation Coefficient');

%% Part B
N_test = 20;
x_test = wblrnd(1.2, 2.2, N_test, n);
x_test = 2 * (x_test - min(x_test, [], 'all')) / (max(x_test, [], 'all') - min(x_test, [], 'all')) - 1;

y_test = poissrnd(4, N_test, 1);
y_test = 2 * (y_test - min(y_test)) / (max(y_test) - min(y_test)) - 1;

figure;
subplot(2,1,1); histogram(x_test(:,1)); title('Histogram of x\_test (first dimension)');
subplot(2,1,2); histogram(y_test); title('Histogram of y\_test');

figure;
stem(xcorr(y_test, x_test(:,1), 'coeff'));
title('Cross-Correlation of y\_test and x\_test(:,1)');
xlabel('Lags'); ylabel('Correlation Coefficient');

%% Part C
X_train = [x, ones(N, 1)];
X_test = [x_test, ones(N_test, 1)];

theta = (X_train' * X_train) \ (X_train' * y);
beta = theta(1:end-1); nu = theta(end);

y_pred_train = X_train * theta;
y_pred_test = X_test * theta;

mse_train = mean((y - y_pred_train).^2);
mse_test = mean((y_test - y_pred_test).^2);

fprintf('MSE train data: %.4f\n', mse_train);
fprintf('MSE test data: %.4f\n', mse_test);

%% Part D
sigmas = exp(linspace(-4, 4, 50));
loss_train = zeros(size(sigmas));
loss_test = zeros(size(sigmas));

for i = 1:length(sigmas)
    sigma = sigmas(i);
    lambda = sigma * ones(n,1);
    L = diag([lambda; 0]);
    theta = (X_train' * X_train + L) \ (X_train' * y);

    y_pred_train = X_train * theta;
    y_pred_test = X_test * theta;

    loss_train(i) = sum((y - y_pred_train).^2) + lambda' * theta(1:end-1);
    loss_test(i) = sum((y_test - y_pred_test).^2) + lambda' * theta(1:end-1);
end

figure;
semilogx(sigmas, loss_train, 'b-o', sigmas, loss_test, 'r-o');
xlabel('\sigma'); ylabel('Loss');
legend('Train Loss', 'Test Loss');
title('Loss vs \sigma (Regularized Linear Regression)');
grid on;

%% Part E
loss_train = zeros(size(sigmas));
loss_test = zeros(size(sigmas));

for i = 1:length(sigmas)
    sigma = sigmas(i);
    L = diag([ones(n,1); 0]);
    theta = (X_train' * X_train + sigma^2 * L) \ (X_train' * y);

    y_pred_train = X_train * theta;
    y_pred_test = X_test * theta;
    beta = theta(1:end-1);

    loss_train(i) = sum((y - y_pred_train).^2) + sigma^2 * sum(beta.^2);
    loss_test(i) = sum((y_test - y_pred_test).^2) + sigma^2 * sum(beta.^2);
end

figure;
semilogx(sigmas, loss_train, 'b-o', sigmas, loss_test, 'r-o');
xlabel('\sigma'); ylabel('Loss');
legend('Train Loss', 'Test Loss');
title('Loss vs \sigma (Ridge Regression)');
grid on;

%% Part F
idx1 = y <= 0.5;
X1 = [x(idx1,:), ones(sum(idx1), 1)];
y1 = y(idx1);

idx2 = y >= -0.5;
X2 = [x(idx2,:), ones(sum(idx2), 1)];
y2 = y(idx2);

loss1 = zeros(size(sigmas));
loss2 = zeros(size(sigmas));

for i = 1:length(sigmas)
    sigma = sigmas(i);
    L = diag([ones(n,1); 0]);
    
    theta1 = (X1' * X1 + sigma^2 * L) \ (X1' * y1);
    beta1 = theta1(1:end-1);
    y_pred1 = X1 * theta1;
    loss1(i) = sum((y1 - y_pred1).^2) + sigma^2 * sum(beta1.^2);
    
    theta2 = (X2' * X2 + sigma^2 * L) \ (X2' * y2);
    beta2 = theta2(1:end-1);
    y_pred2 = X2 * theta2;
    loss2(i) = sum((y2 - y_pred2).^2) + sigma^2 * sum(beta2.^2);
end

figure;
semilogx(sigmas, loss1, 'b-o', sigmas, loss2, 'r-o');
xlabel('\sigma'); ylabel('Loss');
legend('Loss for (y ≤ 0.5)', 'Loss for (y ≥ -0.5)');
title('Loss vs \sigma for Two Separate Models');
grid on;
