clc; clear; close all;

%% Part A
n = 6;

P = zeros(n);

for i = 1:n
    alpha = ones(1, n);
    row = gamrnd(alpha, 1); 
    P(i, :) = row / sum(row);
end

disp('Stochastic matrix P:');
disp(P);
%% Part B

nonNegative = all(P >= 0, 'all');

rowSums = sum(P, 2);
rowSumsOK = all(abs(rowSums - 1) < 1e-10);

if nonNegative && rowSumsOK
    disp('P is a valid transition matrix.');
else
    disp('P is NOT a valid transition matrix.');
end
%% Part C

n = 6;

x0_raw = rand(1, n);
x0 = x0_raw / sum(x0_raw);

disp('Initial state vector x0:');
disp(x0);
%% Part D

numSteps = 100;
X = zeros(numSteps + 1, n);
X(1, :) = x0;

for k = 1:numSteps
    X(k+1, :) = X(k, :) * P;
end

disp('Final state vector after 100 steps:');
disp(X(end, :));
%% Part E

figure;
plot(0:numSteps, X, 'LineWidth', 1.5);
xlabel('Time step (k)');
ylabel('State probabilities');
title('Evolution of state vector over time');
legend(arrayfun(@(i) sprintf('State %d', i), 1:n, 'UniformOutput', false));
grid on;
%% Part F

[V, D] = eig(P');

[~, idx] = min(abs(diag(D) - 1));

x_inf = V(:, idx);

x_inf = x_inf / sum(x_inf);

disp('Steady-state vector x_inf:');
disp(x_inf');
%% Part G
difference = norm(X(end, :) - x_inf', 1);
disp('L1-norm difference:');
disp(difference);
%% Part H
eigValues = eig(P);
disp('Eigenvalues of P:');
disp(eigValues);
%% Part I

deltaP = 0.01 * (2 * rand(size(P)) - 1);
P_perturbed = P + deltaP;

P_perturbed(P_perturbed < 0) = 0;

P_perturbed = P_perturbed ./ sum(P_perturbed, 2);

disp('Perturbed transition matrix P + δP:');
disp(P_perturbed);
%% Part J

[V2, D2] = eig(P_perturbed');
[~, idx2] = min(abs(diag(D2) - 1));
x_inf_perturbed = V2(:, idx2);
x_inf_perturbed = x_inf_perturbed / sum(x_inf_perturbed);

delta_x = norm(x_inf_perturbed - x_inf, 1);

disp('Perturbed steady-state vector:');
disp(x_inf_perturbed');

disp('L1-norm difference from original steady state:');
disp(delta_x);
