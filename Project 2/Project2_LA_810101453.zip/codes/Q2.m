clc; clear; close all;

%% Part A
B = [1 2 3; 2 4.0001 6; 3 6 9];
b = rand(3,1);
disp('Random vector b:');
disp(b)

%% Part B
cond_B = cond(B, 2);
disp(['Condition number of B: ', num2str(cond_B)])

%% Part C
x_true = pinv(B) * b;
b_check = B * x_true;
rel_error = norm(b - b_check) / norm(b);
disp(['Relative error: ', num2str(rel_error)])

%% Part D
epsilons = logspace(-12, -1, 50);
rel_errors = zeros(size(epsilons));

for i = 1:length(epsilons)
    e = epsilons(i);
    noise = e * randn(3,1);     
    b_perturbed = b + noise;

    x_perturbed = pinv(B) * b_perturbed;
    rel_errors(i) = norm(x_true - x_perturbed) / norm(x_true);
end

figure;
loglog(epsilons, rel_errors, 'o-','LineWidth',1.5)
xlabel('\epsilon (perturbation size)')
ylabel('Relative error in solution')
title('Sensitivity of solution to perturbations in b')
grid on
