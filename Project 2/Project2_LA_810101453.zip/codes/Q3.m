clc; clear; close all;

%% Part A
k = 3;
n = 5;

P = randi([0 1], k, n - k);
G = [eye(k), P];    
disp('Generator matrix G:');
disp(G);
%% Part B 
numMessages = 10;
messages = randi([0,1], numMessages, k);
codewords = mod(messages * G, 2);

disp('Messages:');
disp(messages);
disp('Encoded Codewords:');
disp(codewords);
%% Part C
p = 0.1;

noise = rand(size(codewords)) < p;

received = mod(codewords + noise, 2); 

disp('Received Codewords:');
disp(received);
%% Part E

H = [P.' , eye(n - k)];
syndromes = mod(received * H', 2);

disp('Parity-check matrix H:');
disp(H);
disp('Syndromes:');
disp(syndromes);
%% Part F

errorDetected = any(syndromes, 2);

disp('Detected Errors (1 = error detected, 0 = no error):');
disp(errorDetected);

numDetected = sum(errorDetected);
fprintf('Number of detected errors: %d out of %d received vectors.\n', numDetected, size(received,1));
