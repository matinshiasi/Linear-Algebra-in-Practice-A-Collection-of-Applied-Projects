clc; clear; close all;

%% Part A
A1 = [0.9 0.3; -0.1 0.8];
A2 = [1.1 0.4; -0.2 1.0];

numVectors = 100;
dim = 2;
mu = 0;
sigma = sqrt(5);
x0 = sigma * randn(dim, numVectors) + mu;

%% Part B
T = 100;
X_end_A1 = zeros(dim, numVectors);
X_end_A2 = zeros(dim, numVectors);

trajectories_A1 = zeros(dim, T+1, numVectors);
trajectories_A2 = zeros(dim, T+1, numVectors);

for i = 1:numVectors
    x_A1 = x0(:,i);
    x_A2 = x0(:,i);
    trajectories_A1(:,1,i) = x_A1;
    trajectories_A2(:,1,i) = x_A2;
    for t = 1:T
        x_A1 = A1 * x_A1;
        x_A2 = A2 * x_A2;
        trajectories_A1(:,t+1,i) = x_A1;
        trajectories_A2(:,t+1,i) = x_A2;
    end
    X_end_A1(:,i) = x_A1;
    X_end_A2(:,i) = x_A2;
end

mean_A1 = mean(X_end_A1, 2);
mean_A2 = mean(X_end_A2, 2);

disp('Mean ending point for A1:')
disp(mean_A1)

disp('Mean ending point for A2:')
disp(mean_A2)

%% Part C
eig_A1 = eig(A1);
eig_A2 = eig(A2);

disp('Eigenvalues of A1:')
disp(eig_A1)
disp('Eigenvalues of A2:')
disp(eig_A2)

if all(abs(eig_A1) < 1)
    disp('System with A1 is stable')
elseif any(abs(eig_A1) == 1)
    disp('System with A1 is asymptotically stable')
else
    disp('System with A1 is unstable')
end

if all(abs(eig_A2) < 1)
    disp('System with A2 is stable')
elseif any(abs(eig_A2) == 1)
    disp('System with A2 is asymptotically stable')
else
    disp('System with A2 is unstable')
end

%% Part D
figure;
hold on
for i = 1:numVectors
    traj = trajectories_A1(:,:,i);
    plot(traj(1,:), traj(2,:))
end
title('Phase Portrait for A1 (No Noise)')
xlabel('x1')
ylabel('x2')
axis equal
grid on

figure;
hold on
for i = 1:numVectors
    traj = trajectories_A2(:,:,i);
    plot(traj(1,:), traj(2,:))
end
title('Phase Portrait for A2 (No Noise)')
xlabel('x1')
ylabel('x2')
axis equal
grid on

%% Part E
trajectories_A1_noise = zeros(dim, T+1, numVectors);
trajectories_A2_noise = zeros(dim, T+1, numVectors);

for i = 1:numVectors
    x_A1 = x0(:,i);
    x_A2 = x0(:,i);
    trajectories_A1_noise(:,1,i) = x_A1;
    trajectories_A2_noise(:,1,i) = x_A2;
    for t = 1:T
        eta1 = randn(dim,1);
        eta2 = randn(dim,1);
        x_A1 = A1 * x_A1 + eta1;
        x_A2 = A2 * x_A2 + eta2;
        trajectories_A1_noise(:,t+1,i) = x_A1;
        trajectories_A2_noise(:,t+1,i) = x_A2;
    end
end

figure;
hold on
for i = 1:numVectors
    traj = trajectories_A1_noise(:,:,i);
    plot(traj(1,:), traj(2,:))
end
title('Phase Portrait for A1 (With Noise)')
xlabel('x1')
ylabel('x2')
axis equal
grid on

figure;
hold on
for i = 1:numVectors
    traj = trajectories_A2_noise(:,:,i);
    plot(traj(1,:), traj(2,:))
end
title('Phase Portrait for A2 (With Noise)')
xlabel('x1')
ylabel('x2')
axis equal
grid on
